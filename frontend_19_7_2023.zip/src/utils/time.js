export function getTime() {
  return new Date().toLocaleDateString();
}
